import 'package:flutter/material.dart';
import 'app_localizations.dart';

class AppLocalizationsVi extends AppLocalizations {
  // Common
  @override
  String get appName => 'Đặt Phòng Khách Sạn';
  @override
  String get language => 'Ngôn ngữ';
  @override
  String get ok => 'Đồng ý';
  @override
  String get cancel => 'Hủy';
  @override
  String get yes => 'Có';
  @override
  String get no => 'Không';
  @override
  String get save => 'Lưu';
  @override
  String get delete => 'Xóa';
  @override
  String get edit => 'Chỉnh sửa';
  @override
  String get loading => 'Đang tải...';
  @override
  String get error => 'Lỗi';
  @override
  String get success => 'Thành công';
  @override
  String get retry => 'Thử lại';
  @override
  String get close => 'Đóng';
  @override
  String get search => 'Tìm kiếm';
  @override
  String get filter => 'Bộ lọc';
  @override
  String get sort => 'Sắp xếp';
  @override
  String get required => 'Bắt buộc';
  @override
  String get optional => 'Tùy chọn';
  
  // Navigation
  @override
  String get home => 'Trang chủ';
  @override
  String get profile => 'Hồ sơ';
  @override
  String get settings => 'Cài đặt';
  @override
  String get logout => 'Đăng xuất';
  @override
  String get back => 'Quay lại';
  @override
  String get next => 'Tiếp tục';
  @override
  String get previous => 'Trước';
  @override
  String get finish => 'Hoàn thành';
  
  // Auth
  @override
  String get login => 'Đăng nhập';
  @override
  String get register => 'Đăng ký';
  @override
  String get forgotPassword => 'Quên mật khẩu';
  @override
  String get resetPassword => 'Đặt lại mật khẩu';
  @override
  String get verifyEmail => 'Xác thực email';
  @override
  String get resendCode => 'Gửi lại mã';
  @override
  String get emailAddress => 'Địa chỉ email';
  @override
  String get password => 'Mật khẩu';
  @override
  String get confirmPassword => 'Xác nhận mật khẩu';
  @override
  String get firstName => 'Tên';
  @override
  String get lastName => 'Họ';
  @override
  String get phoneNumber => 'Số điện thoại';
  @override
  String get verificationCode => 'Mã xác thực';
  @override
  String get newPassword => 'Mật khẩu mới';
  @override
  String get currentPassword => 'Mật khẩu hiện tại';
  @override
  String get loginSuccess => 'Đăng nhập thành công';
  @override
  String get registerSuccess => 'Đăng ký thành công';
  @override
  String get logoutSuccess => 'Đăng xuất thành công';
  @override
  String get passwordResetSuccess => 'Đặt lại mật khẩu thành công';
  @override
  String get emailVerified => 'Xác thực email thành công';
  @override
  String get invalidEmail => 'Email không hợp lệ';
  @override
  String get invalidPassword => 'Mật khẩu không hợp lệ';
  @override
  String get passwordMismatch => 'Mật khẩu không khớp';
  @override
  String get weakPassword => 'Mật khẩu quá yếu';
  @override
  String get emailExists => 'Email đã tồn tại';
  @override
  String get invalidCredentials => 'Email hoặc mật khẩu không đúng';
  @override
  String get accountNotVerified => 'Tài khoản chưa được xác thực';
  @override
  String get otpExpired => 'Mã xác thực đã hết hạn';
  @override
  String get invalidOtp => 'Mã xác thực không hợp lệ';
  @override
  String get loginPrompt => 'Vui lòng đăng nhập để tiếp tục';
  @override
  String get registerPrompt => 'Tạo tài khoản của bạn';
  @override
  String get forgotPasswordPrompt => 'Nhập email để đặt lại mật khẩu';
  @override
  String get verificationPrompt => 'Nhập mã xác thực đã gửi đến email của bạn';
  @override
  String get dontHaveAccount => 'Chưa có tài khoản?';
  @override
  String get alreadyHaveAccount => 'Đã có tài khoản?';
  @override
  String get rememberMe => 'Ghi nhớ đăng nhập';
  @override
  String get terms => 'Điều khoản dịch vụ';
  @override
  String get privacy => 'Chính sách bảo mật';
  @override
  String get agreeToTerms => 'Tôi đồng ý với Điều khoản dịch vụ và Chính sách bảo mật';
  
  // User Roles
  @override
  String get customer => 'Khách hàng';
  @override
  String get hotelOwner => 'Chủ khách sạn';
  @override
  String get admin => 'Quản trị viên';
  @override
  String get selectRole => 'Chọn vai trò của bạn';
  
  // User Tiers
  @override
  String get silverTier => 'Bạc';
  @override
  String get goldTier => 'Vàng';
  @override
  String get diamondTier => 'Kim cương';
  @override
  String get discountBenefit => 'Giảm giá 5% cho tất cả đặt phòng';
  
  // Hotels
  @override
  String get hotels => 'Khách sạn';
  @override
  String get hotelName => 'Tên khách sạn';
  @override
  String get hotelDescription => 'Mô tả';
  @override
  String get hotelAddress => 'Địa chỉ';
  @override
  String get hotelAmenities => 'Tiện nghi';
  @override
  String get checkIn => 'Nhận phòng';
  @override
  String get checkOut => 'Trả phòng';
  @override
  String get guests => 'Khách';
  @override
  String get rooms => 'Phòng';
  @override
  String get room => 'Phòng';
  @override
  String get roomType => 'Loại phòng';
  @override
  String get pricePerNight => 'Giá mỗi đêm';
  @override
  String get totalPrice => 'Tổng giá';
  @override
  String get availability => 'Tình trạng';
  @override
  String get available => 'Còn phòng';
  @override
  String get notAvailable => 'Hết phòng';
  @override
  String get bookNow => 'Đặt ngay';
  @override
  String get bookRoom => 'Đặt phòng';
  @override
  String get booking => 'Đặt phòng';
  @override
  String get bookings => 'Đặt phòng';
  @override
  String get bookingHistory => 'Lịch sử đặt phòng';
  @override
  String get bookingConfirmed => 'Đặt phòng đã xác nhận';
  @override
  String get bookingCancelled => 'Đặt phòng đã hủy';
  @override
  String get bookingPending => 'Đặt phòng chờ xử lý';
  @override
  String get bookingCompleted => 'Đặt phòng đã hoàn thành';
  @override
  String get cancelBooking => 'Hủy đặt phòng';
  @override
  String get viewBooking => 'Xem đặt phòng';
  @override
  String get editBooking => 'Sửa đặt phòng';

  // Guest info
  @override
  String get adults => 'Người lớn';
  @override
  String get children => 'Trẻ em';
  @override
  String get hotel => 'Khách sạn';
  @override
  String get specialRequests => 'Yêu cầu đặc biệt';

  // Additional booking strings
  @override
  String get completed => 'Hoàn thành';
  @override
  String get startBookingToSeeHere => 'Bắt đầu đặt phòng để xem đặt chỗ của bạn tại đây';
  @override
  String get searchHotels => 'Tìm khách sạn';
  @override
  String get selectDates => 'Chọn ngày';
  @override
  String get nights => 'đêm';
  @override
  String get guestInformation => 'Thông tin khách';
  @override
  String get specialRequestsHint => 'Có yêu cầu đặc biệt nào không? (tùy chọn)';
  @override
  String get bookingSummary => 'Tóm tắt đặt phòng';
  @override
  String get memberDiscount => 'Giảm giá thành viên';
  @override
  String get tax => 'Thuế';
  @override
  String get total => 'Tổng cộng';
  @override
  String get selectCheckInFirst => 'Vui lòng chọn ngày nhận phòng trước';
  
  // Reviews
  @override
  String get reviews => 'Đánh giá';
  @override
  String get review => 'Đánh giá';
  @override
  String get rating => 'Xếp hạng';
  @override
  String get writeReview => 'Viết đánh giá';
  @override
  String get rateHotel => 'Đánh giá khách sạn';
  @override
  String get reviewSubmitted => 'Gửi đánh giá thành công';
  @override
  String get noReviews => 'Chưa có đánh giá';
  @override
  String get averageRating => 'Đánh giá trung bình';
  @override
  String get totalReviews => 'Tổng đánh giá';
  
  // Search & Filter;
  @override
  String get location => 'Vị trí';
  @override
  String get priceRange => 'Khoảng giá';
  @override
  String get starRating => 'Xếp hạng sao';
  @override
  String get sortBy => 'Sắp xếp theo';
  @override
  String get sortByPrice => 'Giá';
  @override
  String get sortByRating => 'Đánh giá';
  @override
  String get sortByName => 'Tên';
  @override
  String get filterResults => 'Lọc kết quả';
  @override
  String get clearFilters => 'Xóa bộ lọc';
  @override
  String get noResults => 'Không tìm thấy kết quả';
  @override
  String get searchResults => 'Kết quả tìm kiếm';
  
  // Payment
  @override
  String get payment => 'Thanh toán';
  @override
  String get paymentMethod => 'Phương thức thanh toán';
  @override
  String get paymentSuccess => 'Thanh toán thành công';
  @override
  String get paymentFailed => 'Thanh toán thất bại';
  @override
  String get paymentPending => 'Đang xử lý thanh toán';
  @override
  String get payNow => 'Thanh toán ngay';
  @override
  String get totalAmount => 'Tổng tiền';
  @override
  String get paymentHistory => 'Lịch sử thanh toán';
  
  // Favorites
  @override
  String get favorites => 'Yêu thích';
  @override
  String get addToFavorites => 'Thêm vào yêu thích';
  @override
  String get removeFromFavorites => 'Xóa khỏi yêu thích';
  @override
  String get noFavorites => 'Chưa có mục yêu thích';
  
  // Profile
  @override
  String get editProfile => 'Chỉnh sửa hồ sơ';
  @override
  String get updateProfile => 'Cập nhật hồ sơ';
  @override
  String get profileUpdated => 'Cập nhật hồ sơ thành công';
  @override
  String get changePassword => 'Đổi mật khẩu';
  @override
  String get passwordChanged => 'Đổi mật khẩu thành công';
  @override
  String get personalInfo => 'Thông tin cá nhân';
  @override
  String get contactInfo => 'Thông tin liên hệ';
  @override
  String get accountSettings => 'Cài đặt tài khoản';
  @override
  String get notifications => 'Thông báo';
  @override
  String get appSettings => 'Cài đặt ứng dụng';
  
  // Errors
  @override
  String get networkError => 'Lỗi kết nối mạng';
  @override
  String get serverError => 'Lỗi máy chủ';
  @override
  String get unknownError => 'Đã xảy ra lỗi không xác định';
  @override
  String get sessionExpired => 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại';
  @override
  String get accessDenied => 'Truy cập bị từ chối';
  @override
  String get notFound => 'Không tìm thấy tài nguyên';
  @override
  String get validationError => 'Lỗi xác thực';
  @override
  String get fieldRequired => 'Trường này là bắt buộc';
  @override
  String get invalidFormat => 'Định dạng không hợp lệ';
  @override
  String get passwordTooShort => 'Mật khẩu quá ngắn';
  @override
  String get passwordTooLong => 'Mật khẩu quá dài';
  
  // Hotel Owner
  @override
  String get myHotels => 'Khách sạn của tôi';
  @override
  String get addHotel => 'Thêm khách sạn';
  @override
  String get editHotel => 'Sửa khách sạn';
  @override
  String get deleteHotel => 'Xóa khách sạn';
  @override
  String get hotelManagement => 'Quản lý khách sạn';
  @override
  String get roomManagement => 'Quản lý phòng';
  @override
  String get addRoom => 'Thêm phòng';
  @override
  String get editRoom => 'Sửa phòng';
  @override
  String get hotelStats => 'Thống kê khách sạn';
  @override
  String get revenue => 'Doanh thu';
  @override
  String get noHotelsFound => 'Không tìm thấy khách sạn';
  @override
  String get tryDifferentSearch => 'Thử tìm kiếm khác';
  @override
  String get addYourFirstHotel => 'Thêm khách sạn đầu tiên để bắt đầu';
  @override
  String get addHotelDescription => 'Tạo danh sách khách sạn mới để bắt đầu nhận đặt phòng';
  @override
  String get editHotelDescription => 'Bạn có muốn chỉnh sửa khách sạn';
  @override
  String get deleteHotelConfirmation => 'Bạn có chắc muốn xóa khách sạn';
  @override
  String get deletedSuccessfully => 'đã xóa thành công';
  @override
  String get failedToDelete => 'Không thể xóa';
  @override
  String get deleting => 'Đang xóa';
  @override
  String get view => 'Xem';
  @override
  String get active => 'Hoạt động';
  @override
  String get inactive => 'Không hoạt động';
  @override
  String get continue_ => 'Tiếp tục';
  @override
  String get monthlyRevenue => 'Doanh thu tháng';
  @override
  String get totalBookings => 'Tổng đặt phòng';
  @override
  String get occupancyRate => 'Tỷ lệ lấp đầy';
  @override
  String get guestManagement => 'Quản lý khách';
  @override
  String get checkInGuest => 'Nhận khách';
  @override
  String get checkOutGuest => 'Trả phòng khách';
  
  // Admin
  @override
  String get dashboard => 'Bảng điều khiển';
  @override
  String get userManagement => 'Quản lý người dùng';
  @override
  String get systemSettings => 'Cài đặt hệ thống';
  @override
  String get reports => 'Báo cáo';
  @override
  String get analytics => 'Phân tích';
  @override
  String get approveHotel => 'Duyệt khách sạn';
  @override
  String get rejectHotel => 'Từ chối khách sạn';
  @override
  String get pendingApproval => 'Chờ duyệt';
  @override
  String get approved => 'Đã duyệt';
  @override
  String get rejected => 'Đã từ chối';
  
  // Validation Messages
  @override
  String fieldRequiredMessage(String field) => '$field là bắt buộc';
  
  @override
  String fieldTooShortMessage(String field, int minLength) => 
      '$field phải có ít nhất $minLength ký tự';
  
  @override
  String fieldTooLongMessage(String field, int maxLength) => 
      '$field không được vượt quá $maxLength ký tự';
  
  @override
  String invalidEmailMessage() => 'Vui lòng nhập địa chỉ email hợp lệ';
  
  @override
  String passwordMismatchMessage() => 'Mật khẩu không khớp';
  
  @override
  String weakPasswordMessage() => 
      'Mật khẩu phải có ít nhất 6 ký tự';
  
  @override
  String networkErrorMessage() => 
      'Kết nối mạng thất bại. Vui lòng kiểm tra kết nối internet';
  
  @override
  String serverErrorMessage() => 
      'Lỗi máy chủ. Vui lòng thử lại sau';
  
  // Main App Navigation - New additions only
  @override
  String get welcomeMessage => 'Chào mừng trở lại!';
  @override
  String get findYourPerfectStay => 'Tìm nơi lưu trú hoàn hảo';
  @override
  String get quickActions => 'Thao tác nhanh';
  @override
  String get recentBookings => 'Đặt phòng gần đây';
  @override
  String get nearbyHotels => 'Khách sạn gần đây';
  @override
  String get popularDestinations => 'Điểm đến phổ biến';
  @override
  String get featuredHotels => 'Khách sạn nổi bật';
  @override
  String get seeAll => 'Xem tất cả';
  @override
  String get comingSoon => 'Sắp ra mắt';
  
  // Search - New additions only
  @override
  String get searchForHotels => 'Tìm kiếm khách sạn';
  @override
  String get destination => 'Điểm đến';
  @override
  String get enterDestination => 'Nhập tên thành phố hoặc khách sạn';
  @override
  String get selectDate => 'Chọn ngày';
  
  // Bookings - New additions only
  @override
  String get upcoming => 'Sắp tới';
  @override
  String get cancelled => 'Đã hủy';
  @override
  String get noBookingsFound => 'Không tìm thấy đặt phòng nào';

  // Profile - New additions only
  @override
  String get guest => 'Khách';
  @override
  String get paymentMethods => 'Phương thức thanh toán';
  @override
  String get helpSupport => 'Trợ giúp & Hỗ trợ';
  @override
  String get privacyPolicy => 'Chính sách bảo mật';
  @override
  String get selectLanguage => 'Chọn ngôn ngữ';
  @override
  String get logoutConfirmation => 'Bạn có chắc chắn muốn đăng xuất?';
  
  // Hotel Owner Dashboard - New additions only
  @override
  String get welcome => 'Chào mừng';
  @override
  String get manageYourHotelBusiness => 'Quản lý kinh doanh khách sạn';
  @override
  String get overview => 'Tổng quan';
  @override
  String get totalRooms => 'Tổng số phòng';
  @override
  String get manageHotels => 'Quản lý khách sạn';
  @override
  String get addEditHotels => 'Thêm hoặc chỉnh sửa khách sạn';
  @override
  String get manageRooms => 'Quản lý phòng';
  @override
  String get addEditRooms => 'Thêm hoặc chỉnh sửa phòng';
  @override
  String get noRoomsFound => 'Không tìm thấy phòng nào';
  @override
  String get addFirstRoom => 'Thêm phòng đầu tiên';
  @override
  String get roomDetails => 'Chi tiết phòng';
  @override
  String get deleteRoom => 'Xóa phòng';
  @override
  String get toggleRoomStatus => 'Thay đổi trạng thái phòng';
  @override
  String get roomDeleted => 'Xóa phòng thành công';
  @override
  String get roomUpdated => 'Cập nhật phòng thành công';
  @override
  String get viewBookings => 'Xem đặt phòng';
  @override
  String get manageReservations => 'Quản lý đặt phòng';
  @override
  String get viewAnalytics => 'Xem phân tích và báo cáo';
  @override
  String get recentActivity => 'Hoạt động gần đây';
  @override
  String get noRecentActivity => 'Không có hoạt động gần đây';
  @override
  String get noRecentBookings => 'Không có đặt phòng gần đây';
  @override
  String get noHotelsYet => 'Chưa có khách sạn nào';
  @override
  String get tryAgain => 'Thử lại';
  @override
  String get manageBookings => 'Quản lý đặt phòng';
  @override
  String get viewAll => 'Xem tất cả';
  @override
  String get all => 'Tất cả';
  @override
  String get pending => 'Chờ xử lý';
  @override
  String get confirmed => 'Đã xác nhận';
  @override
  String get selectHotel => 'Chọn khách sạn';
  @override
  String get allHotels => 'Tất cả khách sạn';
  @override
  String get allStatuses => 'Tất cả trạng thái';

  // Payment & Booking - Customer
  @override
  String get paymentCancelled => 'Đã hủy thanh toán';
  @override
  String get paymentCancelledMessage => 'Bạn đã hủy thanh toán. Bạn có thể thử lại sau.';
  @override
  String get paymentError => 'Lỗi thanh toán';
  @override
  String get backToHome => 'Về trang chủ';
  @override
  String get creatingPayment => 'Đang tạo thanh toán...';
  @override
  String get loadingPayment => 'Đang tải thanh toán...';
  @override
  String get paymentSummary => 'Tóm tắt thanh toán';
  @override
  String get bookingId => 'Mã đặt phòng';
  @override
  String get amount => 'Số tiền';
  @override
  String get cancelPayment => 'Hủy thanh toán';
  @override
  String get cancelPaymentConfirmation => 'Bạn có chắc chắn muốn hủy thanh toán này?';
  @override
  String get continuePayment => 'Tiếp tục thanh toán';
  @override
  String get bookingSuccess => 'Đặt phòng thành công!';
  @override
  String get bookingSuccessMessage => 'Đặt phòng của bạn đã được xác nhận. Chúng tôi đã gửi email xác nhận cho bạn.';
  @override
  String get bookingDetails => 'Chi tiết đặt phòng';
  @override
  String get bookingNumber => 'Số đặt phòng';
  @override
  String get status => 'Trạng thái';
  @override
  String get viewMyBookings => 'Xem đặt phòng của tôi';
  @override
  String get myBookings => 'Đặt phòng của tôi';
  @override
  String get past => 'Đã qua';
  @override
  String get viewHotel => 'Xem khách sạn';
  @override
  String get cancelBookingConfirmation => 'Bạn có chắc chắn muốn hủy đặt phòng này? Hành động này không thể hoàn tác.';
  @override
  String get bookingCancelledSuccessfully => 'Hủy đặt phòng thành công';

  // Chatbot strings
  @override
  String get chatbot => 'Trợ lý ảo';
  @override
  String get chatbotWelcome => 'Xin chào! Tôi là trợ lý ảo của khách sạn. Tôi có thể giúp bạn tìm kiếm khách sạn phù hợp. Hãy hỏi tôi bất cứ điều gì!';
  @override
  String get suggestedQuestions => 'Câu hỏi gợi ý:';
  @override
  String get typeMessage => 'Nhập tin nhắn...';
}

