import 'package:flutter/material.dart';
import 'app_localizations_en.dart';
import 'app_localizations_vi.dart';

abstract class AppLocalizations {
  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static const List<Locale> supportedLocales = [
    Locale('en'),
    Locale('vi'),
  ];

  // Common
  String get appName;
  String get language;
  String get ok;
  String get cancel;
  String get yes;
  String get no;
  String get save;
  String get delete;
  String get edit;
  String get loading;
  String get error;
  String get success;
  String get retry;
  String get close;
  String get search;
  String get filter;
  String get sort;
  String get required;
  String get optional;
  
  // Navigation
  String get home;
  String get profile;
  String get settings;
  String get logout;
  String get back;
  String get next;
  String get previous;
  String get finish;
  
  // Auth
  String get login;
  String get register;
  String get forgotPassword;
  String get resetPassword;
  String get verifyEmail;
  String get resendCode;
  String get emailAddress;
  String get password;
  String get confirmPassword;
  String get firstName;
  String get lastName;
  String get phoneNumber;
  String get verificationCode;
  String get newPassword;
  String get currentPassword;
  String get loginSuccess;
  String get registerSuccess;
  String get logoutSuccess;
  String get passwordResetSuccess;
  String get emailVerified;
  String get invalidEmail;
  String get invalidPassword;
  String get passwordMismatch;
  String get weakPassword;
  String get emailExists;
  String get invalidCredentials;
  String get accountNotVerified;
  String get otpExpired;
  String get invalidOtp;
  String get loginPrompt;
  String get registerPrompt;
  String get forgotPasswordPrompt;
  String get verificationPrompt;
  String get dontHaveAccount;
  String get alreadyHaveAccount;
  String get rememberMe;
  String get terms;
  String get privacy;
  String get agreeToTerms;
  
  // User Roles
  String get customer;
  String get hotelOwner;
  String get admin;
  String get selectRole;
  
  // User Tiers
  String get silverTier;
  String get goldTier;
  String get diamondTier;
  String get discountBenefit;
  
  // Hotels
  String get hotels;
  String get hotelName;
  String get hotelDescription;
  String get hotelAddress;
  String get hotelAmenities;
  String get checkIn;
  String get checkOut;
  String get guests;
  String get rooms;
  String get room;
  String get roomType;
  String get pricePerNight;
  String get totalPrice;
  String get availability;
  String get available;
  String get notAvailable;
  String get bookNow;
  String get bookRoom;
  String get booking;
  String get bookings;
  String get bookingHistory;
  String get bookingConfirmed;
  String get bookingCancelled;
  String get bookingPending;
  String get bookingCompleted;
  String get cancelBooking;
  String get viewBooking;
  String get editBooking;

  // Guest info
  String get adults;
  String get children;
  String get hotel;
  String get specialRequests;

  // Additional booking strings
  String get completed;
  String get startBookingToSeeHere;
  String get searchHotels;
  String get selectDates;
  String get nights;
  String get guestInformation;
  String get specialRequestsHint;
  String get bookingSummary;
  String get memberDiscount;
  String get tax;
  String get total;
  String get selectCheckInFirst;
  
  // Reviews
  String get reviews;
  String get review;
  String get rating;
  String get writeReview;
  String get rateHotel;
  String get reviewSubmitted;
  String get noReviews;
  String get averageRating;
  String get totalReviews;
  
  // Search & Filter
  String get location;
  String get priceRange;
  String get starRating;
  String get sortBy;
  String get sortByPrice;
  String get sortByRating;
  String get sortByName;
  String get filterResults;
  String get clearFilters;
  String get noResults;
  String get searchResults;
  
  // Payment
  String get paymentMethod;
  String get paymentSuccess;
  String get paymentFailed;
  String get paymentPending;
  String get payNow;
  String get totalAmount;
  String get paymentHistory;
  
  // Favorites
  String get favorites;
  String get addToFavorites;
  String get removeFromFavorites;
  String get noFavorites;
  
  // Profile
  String get editProfile;
  String get updateProfile;
  String get profileUpdated;
  String get changePassword;
  String get passwordChanged;
  String get personalInfo;
  String get contactInfo;
  String get accountSettings;
  String get notifications;
  String get appSettings;
  
  // Errors
  String get networkError;
  String get serverError;
  String get unknownError;
  String get sessionExpired;
  String get accessDenied;
  String get notFound;
  String get validationError;
  String get fieldRequired;
  String get invalidFormat;
  String get passwordTooShort;
  String get passwordTooLong;
  
  // Hotel Owner
  String get myHotels;
  String get addHotel;
  String get editHotel;
  String get deleteHotel;
  String get hotelManagement;
  String get roomManagement;
  String get addRoom;
  String get editRoom;
  String get hotelStats;
  String get revenue;
  String get monthlyRevenue;
  String get totalBookings;
  String get occupancyRate;
  String get guestManagement;
  String get noHotelsFound;
  String get tryDifferentSearch;
  String get addYourFirstHotel;
  String get addHotelDescription;
  String get editHotelDescription;
  String get deleteHotelConfirmation;
  String get deletedSuccessfully;
  String get failedToDelete;
  String get deleting;
  String get view;
  String get active;
  String get inactive;
  String get continue_;
  String get checkInGuest;
  String get checkOutGuest;
  
  // Admin
  String get dashboard;
  String get userManagement;
  String get systemSettings;
  String get reports;
  String get analytics;
  String get approveHotel;
  String get rejectHotel;
  String get pendingApproval;
  String get approved;
  String get rejected;
  
  // Validation Messages
  String fieldRequiredMessage(String field);
  String fieldTooShortMessage(String field, int minLength);
  String fieldTooLongMessage(String field, int maxLength);
  String invalidEmailMessage();
  String passwordMismatchMessage();
  String weakPasswordMessage();
  String networkErrorMessage();
  String serverErrorMessage();
  
  // Main App Navigation - New additions only
  String get welcomeMessage;
  String get findYourPerfectStay;
  String get quickActions;
  String get recentBookings;
  String get nearbyHotels;
  String get popularDestinations;
  String get featuredHotels;
  String get seeAll;
  String get comingSoon;
  
  // Search - New additions only
  String get searchForHotels;
  String get destination;
  String get enterDestination;
  String get selectDate;
  
  // Bookings - New additions only
  String get upcoming;
  String get cancelled;
  String get noBookingsFound;

  // Profile - New additions only
  String get guest;
  String get paymentMethods;
  String get helpSupport;
  String get privacyPolicy;
  String get selectLanguage;
  String get logoutConfirmation;
  
  // Hotel Owner Dashboard - New additions only
  String get welcome;
  String get manageYourHotelBusiness;
  String get overview;
  String get totalRooms;
  String get manageHotels;
  String get addEditHotels;
  String get manageRooms;
  String get addEditRooms;
  String get noRoomsFound;
  String get addFirstRoom;
  String get roomDetails;
  String get deleteRoom;
  String get toggleRoomStatus;
  String get roomDeleted;
  String get roomUpdated;
  String get viewBookings;
  String get manageReservations;
  String get viewAnalytics;
  String get recentActivity;
  String get noRecentActivity;
  String get noRecentBookings;
  String get noHotelsYet;
  String get tryAgain;
  String get manageBookings;
  String get viewAll;
  String get all;
  String get pending;
  String get confirmed;
  String get selectHotel;
  String get allHotels;
  String get allStatuses;

  // Payment & Booking - Customer
  String get payment;
  String get paymentCancelled;
  String get paymentCancelledMessage;
  String get paymentError;
  String get backToHome;
  String get creatingPayment;
  String get loadingPayment;
  String get paymentSummary;
  String get bookingId;
  String get amount;
  String get cancelPayment;
  String get cancelPaymentConfirmation;
  String get continuePayment;
  String get bookingSuccess;
  String get bookingSuccessMessage;
  String get bookingDetails;
  String get bookingNumber;
  String get status;
  String get viewMyBookings;
  String get myBookings;
  String get past;
  String get viewHotel;
  String get cancelBookingConfirmation;
  String get bookingCancelledSuccessfully;

  // Chatbot strings
  String get chatbot;
  String get chatbotWelcome;
  String get suggestedQuestions;
  String get typeMessage;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return ['en', 'vi'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    switch (locale.languageCode) {
      case 'vi':
        return AppLocalizationsVi();
      case 'en':
      default:
        return AppLocalizationsEn();
    }
  }

  @override
  bool shouldReload(LocalizationsDelegate<AppLocalizations> old) {
    return false;
  }
}
