import 'package:flutter/material.dart';
import 'app_localizations.dart';

class AppLocalizationsEn extends AppLocalizations {
  // Common
  @override
  String get appName => 'Hotel Booking';
  @override
  String get language => 'Language';
  @override
  String get ok => 'OK';
  @override
  String get cancel => 'Cancel';
  @override
  String get yes => 'Yes';
  @override
  String get no => 'No';
  @override
  String get save => 'Save';
  @override
  String get delete => 'Delete';
  @override
  String get edit => 'Edit';
  @override
  String get loading => 'Loading...';
  @override
  String get error => 'Error';
  @override
  String get success => 'Success';
  @override
  String get retry => 'Retry';
  @override
  String get close => 'Close';
  @override
  String get search => 'Search';
  @override
  String get filter => 'Filter';
  @override
  String get sort => 'Sort';
  @override
  String get required => 'Required';
  @override
  String get optional => 'Optional';
  
  // Navigation
  @override
  String get home => 'Home';
  @override
  String get profile => 'Profile';
  @override
  String get settings => 'Settings';
  @override
  String get logout => 'Logout';
  @override
  String get back => 'Back';
  @override
  String get next => 'Next';
  @override
  String get previous => 'Previous';
  @override
  String get finish => 'Finish';
  
  // Auth
  @override
  String get login => 'Login';
  @override
  String get register => 'Register';
  @override
  String get forgotPassword => 'Forgot Password';
  @override
  String get resetPassword => 'Reset Password';
  @override
  String get verifyEmail => 'Verify Email';
  @override
  String get resendCode => 'Resend Code';
  @override
  String get emailAddress => 'Email Address';
  @override
  String get password => 'Password';
  @override
  String get confirmPassword => 'Confirm Password';
  @override
  String get firstName => 'First Name';
  @override
  String get lastName => 'Last Name';
  @override
  String get phoneNumber => 'Phone Number';
  @override
  String get verificationCode => 'Verification Code';
  @override
  String get newPassword => 'New Password';
  @override
  String get currentPassword => 'Current Password';
  @override
  String get loginSuccess => 'Login successful';
  @override
  String get registerSuccess => 'Registration successful';
  @override
  String get logoutSuccess => 'Logout successful';
  @override
  String get passwordResetSuccess => 'Password reset successful';
  @override
  String get emailVerified => 'Email verified successfully';
  @override
  String get invalidEmail => 'Invalid email address';
  @override
  String get invalidPassword => 'Invalid password';
  @override
  String get passwordMismatch => 'Passwords do not match';
  @override
  String get weakPassword => 'Password is too weak';
  @override
  String get emailExists => 'Email already exists';
  @override
  String get invalidCredentials => 'Invalid email or password';
  @override
  String get accountNotVerified => 'Account not verified';
  @override
  String get otpExpired => 'Verification code expired';
  @override
  String get invalidOtp => 'Invalid verification code';
  @override
  String get loginPrompt => 'Please login to continue';
  @override
  String get registerPrompt => 'Create your account';
  @override
  String get forgotPasswordPrompt => 'Enter your email to reset password';
  @override
  String get verificationPrompt => 'Enter the verification code sent to your email';
  @override
  String get dontHaveAccount => "Don't have an account?";
  @override
  String get alreadyHaveAccount => 'Already have an account?';
  @override
  String get rememberMe => 'Remember me';
  @override
  String get terms => 'Terms of Service';
  @override
  String get privacy => 'Privacy Policy';
  @override
  String get agreeToTerms => 'I agree to the Terms of Service and Privacy Policy';
  
  // User Roles
  @override
  String get customer => 'Customer';
  @override
  String get hotelOwner => 'Hotel Owner';
  @override
  String get admin => 'Administrator';
  @override
  String get selectRole => 'Select your role';
  
  // User Tiers
  @override
  String get silverTier => 'Silver';
  @override
  String get goldTier => 'Gold';
  @override
  String get diamondTier => 'Diamond';
  @override
  String get discountBenefit => '5% discount on all bookings';
  
  // Hotels
  @override
  String get hotels => 'Hotels';
  @override
  String get hotelName => 'Hotel Name';
  @override
  String get hotelDescription => 'Description';
  @override
  String get hotelAddress => 'Address';
  @override
  String get hotelAmenities => 'Amenities';
  @override
  String get checkIn => 'Check In';
  @override
  String get checkOut => 'Check Out';
  @override
  String get guests => 'Guests';
  @override
  String get rooms => 'Rooms';
  @override
  String get room => 'Room';
  @override
  String get roomType => 'Room Type';
  @override
  String get pricePerNight => 'Price per Night';
  @override
  String get totalPrice => 'Total Price';
  @override
  String get availability => 'Availability';
  @override
  String get available => 'Available';
  @override
  String get notAvailable => 'Not Available';
  @override
  String get bookNow => 'Book Now';
  @override
  String get bookRoom => 'Book Room';
  @override
  String get booking => 'Booking';
  @override
  String get bookings => 'Bookings';
  @override
  String get bookingHistory => 'Booking History';
  @override
  String get bookingConfirmed => 'Booking Confirmed';
  @override
  String get bookingCancelled => 'Booking Cancelled';
  @override
  String get bookingPending => 'Booking Pending';
  @override
  String get bookingCompleted => 'Booking Completed';
  @override
  String get cancelBooking => 'Cancel Booking';
  @override
  String get viewBooking => 'View Booking';
  @override
  String get editBooking => 'Edit Booking';

  // Guest info
  @override
  String get adults => 'Adults';
  @override
  String get children => 'Children';
  @override
  String get hotel => 'Hotel';
  @override
  String get specialRequests => 'Special Requests';

  // Additional booking strings
  @override
  String get completed => 'Completed';
  @override
  String get startBookingToSeeHere => 'Start booking to see your reservations here';
  @override
  String get searchHotels => 'Search Hotels';
  @override
  String get selectDates => 'Select Dates';
  @override
  String get nights => 'nights';
  @override
  String get guestInformation => 'Guest Information';
  @override
  String get specialRequestsHint => 'Any special requests? (optional)';
  @override
  String get bookingSummary => 'Booking Summary';
  @override
  String get memberDiscount => 'Member Discount';
  @override
  String get tax => 'Tax';
  @override
  String get total => 'Total';
  @override
  String get selectCheckInFirst => 'Please select check-in date first';
  
  // Reviews
  @override
  String get reviews => 'Reviews';
  @override
  String get review => 'Review';
  @override
  String get rating => 'Rating';
  @override
  String get writeReview => 'Write Review';
  @override
  String get rateHotel => 'Rate Hotel';
  @override
  String get reviewSubmitted => 'Review submitted successfully';
  @override
  String get noReviews => 'No reviews yet';
  @override
  String get averageRating => 'Average Rating';
  @override
  String get totalReviews => 'Total Reviews';
  
  // Search & Filter
  @override
  String get location => 'Location';
  @override
  String get priceRange => 'Price Range';
  @override
  String get starRating => 'Star Rating';
  @override
  String get sortBy => 'Sort By';
  @override
  String get sortByPrice => 'Price';
  @override
  String get sortByRating => 'Rating';
  @override
  String get sortByName => 'Name';
  @override
  String get filterResults => 'Filter Results';
  @override
  String get clearFilters => 'Clear Filters';
  @override
  String get noResults => 'No results found';
  @override
  String get searchResults => 'Search Results';
  
  // Payment
  @override
  String get payment => 'Payment';
  @override
  String get paymentMethod => 'Payment Method';
  @override
  String get paymentSuccess => 'Payment successful';
  @override
  String get paymentFailed => 'Payment failed';
  @override
  String get paymentPending => 'Payment pending';
  @override
  String get payNow => 'Pay Now';
  @override
  String get totalAmount => 'Total Amount';
  @override
  String get paymentHistory => 'Payment History';
  
  // Favorites
  @override
  String get favorites => 'Favorites';
  @override
  String get addToFavorites => 'Add to Favorites';
  @override
  String get removeFromFavorites => 'Remove from Favorites';
  @override
  String get noFavorites => 'No favorites yet';
  
  // Profile
  @override
  String get editProfile => 'Edit Profile';
  @override
  String get updateProfile => 'Update Profile';
  @override
  String get profileUpdated => 'Profile updated successfully';
  @override
  String get changePassword => 'Change Password';
  @override
  String get passwordChanged => 'Password changed successfully';
  @override
  String get personalInfo => 'Personal Information';
  @override
  String get contactInfo => 'Contact Information';
  @override
  String get accountSettings => 'Account Settings';
  @override
  String get notifications => 'Notifications';
  @override
  String get appSettings => 'App Settings';
  
  // Errors
  @override
  String get networkError => 'Network connection error';
  @override
  String get serverError => 'Server error occurred';
  @override
  String get unknownError => 'An unknown error occurred';
  @override
  String get sessionExpired => 'Session expired. Please login again';
  @override
  String get accessDenied => 'Access denied';
  @override
  String get notFound => 'Resource not found';
  @override
  String get validationError => 'Validation error';
  @override
  String get fieldRequired => 'This field is required';
  @override
  String get invalidFormat => 'Invalid format';
  @override
  String get passwordTooShort => 'Password is too short';
  @override
  String get passwordTooLong => 'Password is too long';
  
  // Hotel Owner
  @override
  String get myHotels => 'My Hotels';
  @override
  String get addHotel => 'Add Hotel';
  @override
  String get editHotel => 'Edit Hotel';
  @override
  String get deleteHotel => 'Delete Hotel';
  @override
  String get hotelManagement => 'Hotel Management';
  @override
  String get roomManagement => 'Room Management';
  @override
  String get addRoom => 'Add Room';
  @override
  String get editRoom => 'Edit Room';
  @override
  String get hotelStats => 'Hotel Statistics';
  @override
  String get revenue => 'Revenue';
  @override
  String get noHotelsFound => 'No hotels found';
  @override
  String get tryDifferentSearch => 'Try a different search term';
  @override
  String get addYourFirstHotel => 'Add your first hotel to get started';
  @override
  String get addHotelDescription => 'Create a new hotel listing to start accepting bookings';
  @override
  String get editHotelDescription => 'Do you want to edit hotel';
  @override
  String get deleteHotelConfirmation => 'Are you sure you want to delete hotel';
  @override
  String get deletedSuccessfully => 'deleted successfully';
  @override
  String get failedToDelete => 'Failed to delete';
  @override
  String get deleting => 'Deleting';
  @override
  String get view => 'View';
  @override
  String get active => 'Active';
  @override
  String get inactive => 'Inactive';
  @override
  String get continue_ => 'Continue';
  @override
  String get monthlyRevenue => 'Monthly Revenue';
  @override
  String get totalBookings => 'Total Bookings';
  @override
  String get occupancyRate => 'Occupancy Rate';
  @override
  String get guestManagement => 'Guest Management';
  @override
  String get checkInGuest => 'Check In Guest';
  @override
  String get checkOutGuest => 'Check Out Guest';
  
  // Admin
  @override
  String get dashboard => 'Dashboard';
  @override
  String get userManagement => 'User Management';
  @override
  String get systemSettings => 'System Settings';
  @override
  String get reports => 'Reports';
  @override
  String get analytics => 'Analytics';
  @override
  String get approveHotel => 'Approve Hotel';
  @override
  String get rejectHotel => 'Reject Hotel';
  @override
  String get pendingApproval => 'Pending Approval';
  @override
  String get approved => 'Approved';
  @override
  String get rejected => 'Rejected';
  
  // Validation Messages
  @override
  String fieldRequiredMessage(String field) => '$field is required';
  
  @override
  String fieldTooShortMessage(String field, int minLength) => 
      '$field must be at least $minLength characters';
  
  @override
  String fieldTooLongMessage(String field, int maxLength) => 
      '$field must not exceed $maxLength characters';
  
  @override
  String invalidEmailMessage() => 'Please enter a valid email address';
  
  @override
  String passwordMismatchMessage() => 'Passwords do not match';
  
  @override
  String weakPasswordMessage() => 
      'Password must contain at least 6 characters';
  
  @override
  String networkErrorMessage() => 
      'Network connection failed. Please check your internet connection';
  
  @override
  String serverErrorMessage() => 
      'Server error occurred. Please try again later';
  
  // Main App Navigation - New additions only
  @override
  String get welcomeMessage => 'Welcome back!';
  @override
  String get findYourPerfectStay => 'Find your perfect stay';
  @override
  String get quickActions => 'Quick Actions';
  @override
  String get recentBookings => 'Recent Bookings';
  @override
  String get nearbyHotels => 'Nearby Hotels';
  @override
  String get popularDestinations => 'Popular Destinations';
  @override
  String get featuredHotels => 'Featured Hotels';
  @override
  String get seeAll => 'See All';
  @override
  String get comingSoon => 'Coming Soon';
  
  // Search - New additions only
  @override
  String get searchForHotels => 'Search for Hotels';
  @override
  String get destination => 'Destination';
  @override
  String get enterDestination => 'Enter destination city or hotel name';
  @override
  String get selectDate => 'Select Date';
  
  // Bookings - New additions only
  @override
  String get upcoming => 'Upcoming';
  @override
  String get cancelled => 'Cancelled';
  @override
  String get noBookingsFound => 'No bookings found';

  // Profile - New additions only
  @override
  String get guest => 'Guest';
  @override
  String get paymentMethods => 'Payment Methods';
  @override
  String get helpSupport => 'Help & Support';
  @override
  String get privacyPolicy => 'Privacy Policy';
  @override
  String get selectLanguage => 'Select Language';
  @override
  String get logoutConfirmation => 'Are you sure you want to logout?';
  
  // Hotel Owner Dashboard - New additions only
  @override
  String get welcome => 'Welcome';
  @override
  String get manageYourHotelBusiness => 'Manage your hotel business';
  @override
  String get overview => 'Overview';
  @override
  String get totalRooms => 'Total Rooms';
  @override
  String get manageHotels => 'Manage Hotels';
  @override
  String get addEditHotels => 'Add or edit your hotels';
  @override
  String get manageRooms => 'Manage Rooms';
  @override
  String get addEditRooms => 'Add or edit rooms';
  @override
  String get noRoomsFound => 'No rooms found';
  @override
  String get addFirstRoom => 'Add First Room';
  @override
  String get roomDetails => 'Room Details';
  @override
  String get deleteRoom => 'Delete Room';
  @override
  String get toggleRoomStatus => 'Toggle Room Status';
  @override
  String get roomDeleted => 'Room deleted successfully';
  @override
  String get roomUpdated => 'Room updated successfully';
  @override
  String get viewBookings => 'View Bookings';
  @override
  String get manageReservations => 'Manage reservations';
  @override
  String get viewAnalytics => 'View analytics and reports';
  @override
  String get recentActivity => 'Recent Activity';
  @override
  String get noRecentActivity => 'No recent activity';
  @override
  String get noRecentBookings => 'No recent bookings';
  @override
  String get noHotelsYet => 'No hotels added yet';
  @override
  String get tryAgain => 'Try Again';
  @override
  String get manageBookings => 'Manage Bookings';
  @override
  String get viewAll => 'View All';
  @override
  String get all => 'All';
  @override
  String get pending => 'Pending';
  @override
  String get confirmed => 'Confirmed';
  @override
  String get selectHotel => 'Select Hotel';
  @override
  String get allHotels => 'All Hotels';
  @override
  String get allStatuses => 'All Statuses';

  // Payment & Booking - Customer

  @override
  String get paymentCancelled => 'Payment Cancelled';
  @override
  String get paymentCancelledMessage => 'Your payment has been cancelled. You can try again later.';

  @override
  String get paymentError => 'Payment Error';

  @override
  String get backToHome => 'Back to Home';
  @override
  String get creatingPayment => 'Creating payment...';
  @override
  String get loadingPayment => 'Loading payment...';
  @override
  String get paymentSummary => 'Payment Summary';
  @override
  String get bookingId => 'Booking ID';
  @override
  String get amount => 'Amount';

  @override
  String get cancelPayment => 'Cancel Payment';
  @override
  String get cancelPaymentConfirmation => 'Are you sure you want to cancel this payment?';
  @override
  String get continuePayment => 'Continue Payment';
  @override
  String get bookingSuccess => 'Booking Successful!';
  @override
  String get bookingSuccessMessage => 'Your booking has been confirmed. We have sent you a confirmation email.';
  @override
  String get bookingDetails => 'Booking Details';
  @override
  String get bookingNumber => 'Booking Number';

  @override
  String get status => 'Status';
  @override
  String get viewMyBookings => 'View My Bookings';
  @override
  String get myBookings => 'My Bookings';
  @override
  String get past => 'Past';

  @override
  String get viewHotel => 'View Hotel';

  @override
  String get cancelBookingConfirmation => 'Are you sure you want to cancel this booking? This action cannot be undone.';
  @override
  String get bookingCancelledSuccessfully => 'Booking cancelled successfully';

  // Chatbot strings
  @override
  String get chatbot => 'Chatbot';
  @override
  String get chatbotWelcome => 'Hello! I am your hotel assistant. I can help you find suitable hotels. Ask me anything!';
  @override
  String get suggestedQuestions => 'Suggested questions:';
  @override
  String get typeMessage => 'Type a message...';
}

