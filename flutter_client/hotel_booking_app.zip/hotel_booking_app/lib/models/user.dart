class User {
  final String id;
  final String firstName;
  final String lastName;
  final String email;
  final String? phone;
  final String role; // customer, hotel_owner, admin
  final String? address;
  final bool isActive;
  final bool isApproved;
  final bool isEmailVerified;
  final String tier; // silver, gold, diamond
  final double totalSpent;
  final DateTime createdAt;
  final DateTime updatedAt;
  
  User({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    this.phone,
    required this.role,
    this.address,
    this.isActive = true,
    this.isApproved = true,
    this.isEmailVerified = false,
    this.tier = 'silver',
    this.totalSpent = 0.0,
    required this.createdAt,
    required this.updatedAt,
  });
  
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['_id'] ?? json['id'] ?? '',
      firstName: json['firstName'] ?? '',
      lastName: json['lastName'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'],
      role: json['role'] ?? 'customer',
      address: json['address'],
      isActive: json['isActive'] ?? true,
      isApproved: json['isApproved'] ?? true,
      isEmailVerified: json['isEmailVerified'] ?? false,
      tier: json['tier'] ?? json['membershipTier'] ?? 'silver',
      totalSpent: (json['totalSpent'] ?? 0).toDouble(),
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : DateTime.now(),
      updatedAt: json['updatedAt'] != null 
          ? DateTime.parse(json['updatedAt']) 
          : DateTime.now(),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'phone': phone,
      'role': role,
      'address': address,
      'isActive': isActive,
      'isApproved': isApproved,
      'isEmailVerified': isEmailVerified,
      'tier': tier,
      'totalSpent': totalSpent,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }
  
  String get fullName => '$firstName $lastName';
  
  bool get isCustomer => role == 'customer';
  bool get isHotelOwner => role == 'hotel_owner';
  bool get isAdmin => role == 'admin';
  
  bool get isSilverTier => tier == 'silver';
  bool get isGoldTier => tier == 'gold';
  bool get isDiamondTier => tier == 'diamond';
  
  double get discountPercent {
    if (isDiamondTier) return 5.0;
    return 0.0;
  }
  
  User copyWith({
    String? id,
    String? firstName,
    String? lastName,
    String? email,
    String? phone,
    String? role,
    String? address,
    bool? isActive,
    bool? isApproved,
    bool? isEmailVerified,
    String? tier,
    double? totalSpent,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return User(
      id: id ?? this.id,
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      role: role ?? this.role,
      address: address ?? this.address,
      isActive: isActive ?? this.isActive,
      isApproved: isApproved ?? this.isApproved,
      isEmailVerified: isEmailVerified ?? this.isEmailVerified,
      tier: tier ?? this.tier,
      totalSpent: totalSpent ?? this.totalSpent,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
