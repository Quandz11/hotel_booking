import 'package:flutter/material.dart';

class Room {
  final String id;
  final String hotelId;
  final String name;
  final String type;
  final String description;
  final double price;
  final String currency;
  final int maxGuests;
  final int bedCount;
  final String bedType;
  final double size;
  final String sizeUnit;
  final List<String> amenities;
  final List<String> images;
  final bool isAvailable;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Room({
    required this.id,
    required this.hotelId,
    required this.name,
    required this.type,
    required this.description,
    required this.price,
    required this.currency,
    required this.maxGuests,
    required this.bedCount,
    required this.bedType,
    required this.size,
    required this.sizeUnit,
    required this.amenities,
    required this.images,
    required this.isAvailable,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Room.fromJson(Map<String, dynamic> json) {
    // Handle hotel field - can be either a string ID or populated object
    String extractHotelId(dynamic hotel) {
      if (hotel == null) return '';
      if (hotel is String) return hotel;
      if (hotel is Map<String, dynamic>) return hotel['_id'] ?? '';
      return hotel.toString();
    }

    try {
      // Handle images field - can be list of strings or list of objects
      List<String> parseImages(dynamic images) {
        if (images == null) return [];
        if (images is List) {
          return images.map<String>((image) {
            if (image is String) return image;
            if (image is Map<String, dynamic>) return image['url']?.toString() ?? '';
            return image.toString();
          }).where((url) => url.isNotEmpty).toList();
        }
        return [];
      }
      
      return Room(
        id: json['_id'] ?? '',
        hotelId: extractHotelId(json['hotel']),
        name: json['name'] ?? '',
        type: json['type'] ?? '',
        description: json['description'] ?? '',
        price: (json['price'] ?? json['basePrice'] ?? json['weekendPrice'] ?? 0.0).toDouble(),
        currency: json['currency'] ?? 'VND',
        maxGuests: json['maxGuests'] ?? 1,
        bedCount: json['bedCount'] ?? 1,
        bedType: json['bedType'] ?? 'single',
        size: (json['size'] ?? json['roomSize'] ?? 0.0).toDouble(),
        sizeUnit: json['sizeUnit'] ?? json['sizeType'] ?? 'm²',
        amenities: List<String>.from(json['amenities'] ?? []),
        images: parseImages(json['images']),
        isAvailable: json['isAvailable'] ?? true,
        isActive: json['isActive'] ?? true,
        createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
        updatedAt: DateTime.parse(json['updatedAt'] ?? DateTime.now().toIso8601String()),
      );
    } catch (e) {
      print('❌ Error parsing room JSON: $e');
      print('📄 JSON data: $json');
      rethrow;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'hotel': hotelId,
      'name': name,
      'type': type,
      'description': description,
      'price': price,
      'currency': currency,
      'maxGuests': maxGuests,
      'bedCount': bedCount,
      'bedType': bedType,
      'size': size,
      'sizeUnit': sizeUnit,
      'amenities': amenities,
      'images': images,
      'isAvailable': isAvailable,
      'isActive': isActive,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  String get formattedPrice {
    if (currency == 'VND') {
      return '${price.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
        (Match m) => '${m[1]},',
      )} ₫';
    }
    return '${currency} ${price.toStringAsFixed(2)}';
  }

  String get guestCapacity {
    return maxGuests == 1 ? '1 guest' : '$maxGuests guests';
  }

  String get bedInfo {
    return '$bedCount $bedType bed${bedCount > 1 ? 's' : ''}';
  }

  String get sizeInfo {
    return '${size.toStringAsFixed(0)} $sizeUnit';
  }

  Color get availabilityColor {
    if (!isActive) return Colors.grey;
    return isAvailable ? Colors.green : Colors.red;
  }

  String get availabilityText {
    if (!isActive) return 'Inactive';
    return isAvailable ? 'Available' : 'Occupied';
  }

  // Helper method to get room type icon
  IconData get typeIcon {
    switch (type.toLowerCase()) {
      case 'deluxe':
        return Icons.hotel;
      case 'suite':
        return Icons.apartment;
      case 'standard':
        return Icons.bed;
      case 'family':
        return Icons.family_restroom;
      case 'presidential':
        return Icons.castle;
      default:
        return Icons.room;
    }
  }

  Room copyWith({
    String? id,
    String? hotelId,
    String? name,
    String? type,
    String? description,
    double? price,
    String? currency,
    int? maxGuests,
    int? bedCount,
    String? bedType,
    double? size,
    String? sizeUnit,
    List<String>? amenities,
    List<String>? images,
    bool? isAvailable,
    bool? isActive,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Room(
      id: id ?? this.id,
      hotelId: hotelId ?? this.hotelId,
      name: name ?? this.name,
      type: type ?? this.type,
      description: description ?? this.description,
      price: price ?? this.price,
      currency: currency ?? this.currency,
      maxGuests: maxGuests ?? this.maxGuests,
      bedCount: bedCount ?? this.bedCount,
      bedType: bedType ?? this.bedType,
      size: size ?? this.size,
      sizeUnit: sizeUnit ?? this.sizeUnit,
      amenities: amenities ?? this.amenities,
      images: images ?? this.images,
      isAvailable: isAvailable ?? this.isAvailable,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
