import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/hotel_owner_provider.dart';
import '../../l10n/app_localizations.dart';
import '../../models/room.dart';
import '../../models/hotel.dart';

class RoomManagementScreen extends StatefulWidget {
  const RoomManagementScreen({super.key});

  @override
  State<RoomManagementScreen> createState() => _RoomManagementScreenState();
}

class _RoomManagementScreenState extends State<RoomManagementScreen> {
  String _selectedHotelId = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadRooms();
    });
  }

  Future<void> _loadRooms() async {
    final provider = Provider.of<HotelOwnerProvider>(context, listen: false);
    await provider.loadAllRooms();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.manageRooms),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddRoomDialog(),
          ),
        ],
      ),
      body: Consumer<HotelOwnerProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.error.isNotEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 64, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(
                    provider.error,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _loadRooms,
                    child: Text(l10n.tryAgain),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              // Hotel Filter
              _buildHotelFilter(provider),
              
              // Rooms List
              Expanded(
                child: _buildRoomsList(provider),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddRoomDialog(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildHotelFilter(HotelOwnerProvider provider) {
    final l10n = AppLocalizations.of(context)!;

    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.grey[50],
      child: DropdownButtonFormField<String>(
        value: _selectedHotelId.isEmpty ? null : _selectedHotelId,
        decoration: InputDecoration(
          labelText: l10n.selectHotel,
          border: const OutlineInputBorder(),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        items: [
          DropdownMenuItem<String>(
            value: '',
            child: Text(l10n.allHotels),
          ),
          ...provider.ownedHotels.map((hotel) => DropdownMenuItem<String>(
            value: hotel.id,
            child: Text(hotel.name),
          )),
        ],
        onChanged: (value) {
          setState(() {
            _selectedHotelId = value ?? '';
          });
        },
      ),
    );
  }

  Widget _buildRoomsList(HotelOwnerProvider provider) {
    final l10n = AppLocalizations.of(context)!;
    
    // Filter rooms by selected hotel
    List<Room> filteredRooms = provider.allRooms;
    if (_selectedHotelId.isNotEmpty) {
      filteredRooms = provider.getRoomsForHotel(_selectedHotelId);
    }

    if (filteredRooms.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.room_preferences,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              l10n.noRoomsFound,
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => _showAddRoomDialog(),
              child: Text(l10n.addFirstRoom),
            ),
          ],
        ),
      );
    }

    // Group rooms by hotel
    Map<String, List<Room>> roomsByHotel = {};
    for (final room in filteredRooms) {
      roomsByHotel[room.hotelId] = roomsByHotel[room.hotelId] ?? [];
      roomsByHotel[room.hotelId]!.add(room);
    }

    return RefreshIndicator(
      onRefresh: _loadRooms,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: roomsByHotel.keys.length,
        itemBuilder: (context, index) {
          final hotelId = roomsByHotel.keys.elementAt(index);
          final rooms = roomsByHotel[hotelId]!;
          final hotel = provider.ownedHotels.firstWhere((h) => h.id == hotelId);
          
          return _buildHotelSection(hotel, rooms);
        },
      ),
    );
  }

  Widget _buildHotelSection(Hotel hotel, List<Room> rooms) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Hotel Header
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: Theme.of(context).primaryColor.withOpacity(0.3),
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.business,
                color: Theme.of(context).primaryColor,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      hotel.name,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '${rooms.length} rooms',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => _showAddRoomDialog(hotelId: hotel.id),
                icon: const Icon(Icons.add),
                color: Theme.of(context).primaryColor,
              ),
            ],
          ),
        ),
        
        // Rooms
        ...rooms.map((room) => _buildRoomCard(room)).toList(),
        
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildRoomCard(Room room) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: InkWell(
        onTap: () => _showRoomDetails(room),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Row
              Row(
                children: [
                  // Room Icon
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      room.typeIcon,
                      size: 24,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  const SizedBox(width: 12),
                  
                  // Room Info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          room.name,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${room.type.toUpperCase()} • ${room.bedInfo}',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Status
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: room.availabilityColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: room.availabilityColor.withOpacity(0.3),
                      ),
                    ),
                    child: Text(
                      room.availabilityText,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: room.availabilityColor,
                      ),
                    ),
                  ),
                  
                  // Menu
                  PopupMenuButton<String>(
                    onSelected: (value) => _handleRoomAction(value, room),
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit, size: 18),
                            SizedBox(width: 8),
                            Text('Edit'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'toggle',
                        child: Row(
                          children: [
                            Icon(Icons.toggle_on, size: 18),
                            SizedBox(width: 8),
                            Text('Toggle Status'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, size: 18, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Delete', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // Room Details
              Row(
                children: [
                  // Size
                  Expanded(
                    child: _buildRoomDetail(
                      Icons.straighten,
                      'Size',
                      room.sizeInfo,
                    ),
                  ),
                  
                  // Guests
                  Expanded(
                    child: _buildRoomDetail(
                      Icons.people,
                      'Guests',
                      room.guestCapacity,
                    ),
                  ),
                  
                  // Price
                  Expanded(
                    child: _buildRoomDetail(
                      Icons.attach_money,
                      'Price',
                      room.formattedPrice,
                    ),
                  ),
                ],
              ),
              
              if (room.amenities.isNotEmpty) ...[
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: room.amenities.take(3).map((amenity) => Chip(
                    label: Text(
                      amenity,
                      style: const TextStyle(fontSize: 12),
                    ),
                    backgroundColor: Colors.grey[100],
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  )).toList(),
                ),
                if (room.amenities.length > 3)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      '+${room.amenities.length - 3} more amenities',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                  ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoomDetail(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Colors.grey[600]),
        const SizedBox(width: 4),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _handleRoomAction(String action, Room room) {
    switch (action) {
      case 'edit':
        _showEditRoomDialog(room);
        break;
      case 'toggle':
        _toggleRoomStatus(room);
        break;
      case 'delete':
        _deleteRoom(room);
        break;
    }
  }

  void _showRoomDetails(Room room) {
    showDialog(
      context: context,
      builder: (context) => RoomDetailsDialog(room: room),
    );
  }

  void _showAddRoomDialog({String? hotelId}) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Add room feature will be implemented'),
      ),
    );
  }

  void _showEditRoomDialog(Room room) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Edit room feature will be implemented'),
      ),
    );
  }

  void _toggleRoomStatus(Room room) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Toggle room status feature will be implemented'),
      ),
    );
  }

  void _deleteRoom(Room room) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Room'),
        content: Text('Are you sure you want to delete room "${room.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Delete room feature will be implemented'),
                ),
              );
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class RoomDetailsDialog extends StatelessWidget {
  final Room room;

  const RoomDetailsDialog({super.key, required this.room});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Dialog(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500, maxHeight: 600),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(8),
                  topRight: Radius.circular(8),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      l10n.roomDetails,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
            ),
            
            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Name', room.name),
                    _buildDetailRow('Type', room.type.toUpperCase()),
                    _buildDetailRow('Size', room.sizeInfo),
                    _buildDetailRow('Max Guests', '${room.maxGuests}'),
                    _buildDetailRow('Bed Type', room.bedType),
                    _buildDetailRow('Bed Count', '${room.bedCount}'),
                    _buildDetailRow('Price', room.formattedPrice),
                    _buildDetailRow('Status', room.availabilityText),
                    
                    if (room.description.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text(
                        'Description',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        room.description,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                        ),
                      ),
                    ],
                    
                    if (room.amenities.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text(
                        'Amenities',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: room.amenities.map((amenity) => Chip(
                          label: Text(amenity),
                          backgroundColor: Colors.grey[100],
                        )).toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.grey[600],
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
