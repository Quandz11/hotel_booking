import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../services/api_service.dart';
import '../../l10n/app_localizations.dart';
import '../main/main_screen.dart';
import 'booking_success_screen.dart';

class PaymentScreen extends StatefulWidget {
  final Map<String, dynamic> booking;
  final double paymentAmount;
  final String paymentMethod;

  const PaymentScreen({
    super.key,
    required this.booking,
    required this.paymentAmount,
    required this.paymentMethod,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  late final WebViewController _webViewController;
  bool _isLoading = true;
  bool _isCreatingPayment = true;
  String? _paymentUrl;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initializePayment();
  }

  Future<void> _initializePayment() async {
    try {
      if (widget.paymentMethod == 'vnpay') {
        await _createVNPayPayment();
      } else if (widget.paymentMethod == 'stripe') {
        await _createStripePayment();
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isCreatingPayment = false;
      });
    }
  }

  Future<void> _createVNPayPayment() async {
    try {
      final response = await ApiService().createVNPayPayment(
        widget.booking['_id'],
        null, // bank code (optional)
      );
      
      setState(() {
        _paymentUrl = response['paymentUrl'];
        _isCreatingPayment = false;
      });
      
      _initializeWebView();
    } catch (e) {
      throw Exception('Failed to create VNPay payment: $e');
    }
  }

  Future<void> _createStripePayment() async {
    try {
      final response = await ApiService().createStripePayment(
        widget.booking['_id'],
      );
      
      setState(() {
        _paymentUrl = response['paymentUrl'];
        _isCreatingPayment = false;
      });
      
      _initializeWebView();
    } catch (e) {
      throw Exception('Failed to create Stripe payment: $e');
    }
  }

  void _initializeWebView() {
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            setState(() {
              _isLoading = true;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isLoading = false;
            });
            _handleUrlChange(url);
          },
          onNavigationRequest: (NavigationRequest request) {
            _handleUrlChange(request.url);
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_paymentUrl!));
  }

  void _handleUrlChange(String url) {
    print('🌐 URL changed: $url');
    
    // Check for VNPay return URL
    if (url.contains('vnpay-return') || url.contains('payment-return')) {
      _handlePaymentReturn(url);
    }
    
    // Check for Stripe success/cancel URLs
    if (url.contains('payment-success') || url.contains('success')) {
      _handlePaymentSuccess();
    } else if (url.contains('payment-cancel') || url.contains('cancel')) {
      _handlePaymentCancel();
    }
  }

  void _handlePaymentReturn(String url) {
    // Parse URL parameters to check payment status
    final uri = Uri.parse(url);
    final queryParams = uri.queryParameters;
    
    if (widget.paymentMethod == 'vnpay') {
      final responseCode = queryParams['vnp_ResponseCode'];
      if (responseCode == '00') {
        _handlePaymentSuccess();
      } else {
        _handlePaymentFailure('Payment failed with code: $responseCode');
      }
    }
  }

  void _handlePaymentSuccess() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => BookingSuccessScreen(
          booking: widget.booking,
        ),
      ),
      (route) => false,
    );
  }

  void _handlePaymentCancel() {
    _showDialog(
      title: AppLocalizations.of(context)!.paymentCancelled,
      content: AppLocalizations.of(context)!.paymentCancelledMessage,
      onConfirm: () => _navigateToHome(),
    );
  }

  void _handlePaymentFailure(String reason) {
    _showDialog(
      title: AppLocalizations.of(context)!.paymentFailed,
      content: reason,
      onConfirm: () => _navigateToHome(),
    );
  }

  void _showDialog({
    required String title,
    required String content,
    required VoidCallback onConfirm,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              onConfirm();
            },
            child: Text(AppLocalizations.of(context)!.ok),
          ),
        ],
      ),
    );
  }

  void _navigateToHome() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => const MainScreen(),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.payment),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => _showCancelConfirmation(),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    final l10n = AppLocalizations.of(context)!;

    if (_error != null) {
      return _buildErrorWidget();
    }

    if (_isCreatingPayment) {
      return _buildLoadingWidget(l10n.creatingPayment);
    }

    if (_paymentUrl == null) {
      return _buildErrorWidget();
    }

    return Stack(
      children: [
        WebViewWidget(controller: _webViewController),
        if (_isLoading)
          Container(
            color: Colors.white,
            child: _buildLoadingWidget(l10n.loadingPayment),
          ),
      ],
    );
  }

  Widget _buildLoadingWidget(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          Text(
            message,
            style: const TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          _buildPaymentSummary(),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    final l10n = AppLocalizations.of(context)!;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline,
              size: 64,
              color: Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              l10n.paymentError,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              _error ?? l10n.unknownError,
              style: const TextStyle(fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => _navigateToHome(),
              child: Text(l10n.backToHome),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentSummary() {
    final l10n = AppLocalizations.of(context)!;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              l10n.paymentSummary,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l10n.bookingId),
                Text(
                  widget.booking['bookingNumber'] ?? widget.booking['_id'],
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l10n.amount),
                Text(
                  _formatCurrency(widget.paymentAmount),
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).primaryColor,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l10n.paymentMethod),
                Text(
                  widget.paymentMethod.toUpperCase(),
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showCancelConfirmation() {
    final l10n = AppLocalizations.of(context)!;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.cancelPayment),
        content: Text(l10n.cancelPaymentConfirmation),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(l10n.continuePayment),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _navigateToHome();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: Text(l10n.cancel),
          ),
        ],
      ),
    );
  }

  String _formatCurrency(double amount) {
    return '${amount.toStringAsFixed(0).replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]},',
    )} ₫';
  }
}
